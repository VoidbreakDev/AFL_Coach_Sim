// Optional shim if your Unity version doesn't provide it
namespace System.Runtime.CompilerServices
{
    internal static class IsExternalInit {}
}