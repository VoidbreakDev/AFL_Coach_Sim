namespace AFLCoachSim.Core.Engine.Match
{
    public enum Phase { CenterBounce, Stoppage, OpenPlay, Inside50, ShotOnGoal, KickIn }
}