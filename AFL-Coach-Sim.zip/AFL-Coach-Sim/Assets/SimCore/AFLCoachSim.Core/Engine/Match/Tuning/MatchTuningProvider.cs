// Assets/SimCore/AFLCoachSim.Core/Engine/Match/Tuning/MatchTuningProvider.cs
using UnityEngine;

namespace AFLCoachSim.Core.Engine.Match.Tuning
{
    public static class MatchTuningProvider
    {
        // Location for your shared asset (create it once)
        public const string DefaultAssetPath = "Assets/Config/MatchTuning.asset";

        private static MatchTuning _cached;
        private static MatchTuningSO _asset;

        public static MatchTuning Current
        {
            get
            {
                if (_cached != null) return _cached;

#if UNITY_EDITOR
                // In Editor try to load the asset so live edits flow through
                if (_asset == null)
                {
                    _asset = UnityEditor.AssetDatabase.LoadAssetAtPath<MatchTuningSO>(DefaultAssetPath);
                }
                if (_asset != null) { _cached = _asset.ToRuntime(); return _cached; }
#endif
                // Fallback to baked default
                return MatchTuning.Default;
            }
        }

        public static void Invalidate()
        {
            _cached = null;
        }

#if UNITY_EDITOR
        public static MatchTuningSO GetOrCreateAsset()
        {
            if (_asset == null)
            {
                _asset = UnityEditor.AssetDatabase.LoadAssetAtPath<MatchTuningSO>(DefaultAssetPath);
                if (_asset == null)
                {
                    var dir = System.IO.Path.GetDirectoryName(DefaultAssetPath);
                    if (!System.IO.Directory.Exists(dir))
                        System.IO.Directory.CreateDirectory(dir);

                    _asset = ScriptableObject.CreateInstance<MatchTuningSO>();
                    UnityEditor.AssetDatabase.CreateAsset(_asset, DefaultAssetPath);
                    UnityEditor.AssetDatabase.SaveAssets();
                    UnityEditor.AssetDatabase.Refresh();
                }
            }
            return _asset;
        }
#endif
    }
}