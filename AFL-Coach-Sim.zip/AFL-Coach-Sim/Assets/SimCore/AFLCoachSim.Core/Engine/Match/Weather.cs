namespace AFLCoachSim.Core.Engine.Match
{
    public enum Weather { Clear, Windy, LightRain, HeavyRain }
}