namespace AFLCoachSim.Core.Domain.ValueObjects
{
    public enum Role { KPD, KPF, SMLF, SMLB, MID, WING, HBF, HFF, RUC }
}