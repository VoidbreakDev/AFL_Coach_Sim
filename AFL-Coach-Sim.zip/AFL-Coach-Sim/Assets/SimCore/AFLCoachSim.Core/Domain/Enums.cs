// Domain/Enums.cs
namespace AFLCoachSim.Core.Domain
{
    public enum MatchVenue { Home, Away, Neutral }
}